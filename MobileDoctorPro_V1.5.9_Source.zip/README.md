# Mobile Doctor Pro

English + Telugu Android diagnostic information app. This project reads information exposed by Android and offers a basic manual screen colour/touch test.

## Build an APK with GitHub Actions

The workflow at `.github/workflows/android.yml` builds a debug APK whenever code is pushed to `main`, and can also be started manually from the repository's **Actions** tab.

After a successful run, open the workflow run, scroll to **Artifacts**, and download `MobileDoctorPro-debug-apk`. Extract the downloaded ZIP to get `app-debug.apk`, then install it on your Android phone. Android may ask you to allow installation from that browser/file manager.

## Included diagnostics
- Device model, manufacturer, Android version, build, CPU ABI and security patch
- Battery level, temperature, charging state and Android-reported battery condition
- RAM and internal storage
- Sensor inventory, active network transport and validated internet status
- Camera, microphone and flash feature declarations
- Basic full-screen colour/touch interaction test
- English/Telugu language toggle

## Accuracy and privacy limits
This is a basic diagnostic utility, not a certified service-centre tester. Android does not expose every hardware metric to ordinary apps. A listed sensor or hardware feature does not prove it is working. True battery capacity/health, motherboard electrical faults, full camera/speaker/microphone quality, exact cellular signal/5G mode and some GPU details cannot be reliably measured here. The app does not upload diagnostic data and does not require root.

## Project details
- Application ID: `com.mobiledoctorpro.app`
- Minimum Android: 8.0 (API 26)
- Compile SDK: 35
- Version: 1.0
